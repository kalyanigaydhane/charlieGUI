import os

print(os.path.dirname(__file__) + "\\audio\girlAudio\olivia")