from requests import requests
from vmAssistant import *
from bs4 import *

# Get Location
def get_location():
    try:
        URL = 'https://iplocation.com'
        page = requests.get(URL, headers=headers)
        soup = BeautifulSoup(page.content, 'html.parser')
        city = soup.find(class_='city').get_text()
        country = soup.find(class_='country-name').get_text()
        latitude = soup.find(class_='lat').get_text()
        longitude = soup.find(class_='lng').get_text()
        return city, country, latitude, longitude
    except Exception as e:
        print("Sorry, I cannot find your location")
        speak("Sorry, I cannot find your location")