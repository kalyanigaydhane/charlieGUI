import pyttsx3

# Initialize Text to Speech
engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[1].id)

#Speak Function
def speak(audio):
    engine.say(audio)
    engine.runAndWait()

