from py_avataaars import PyAvataaar  
  
# assigning various parameters to our avatar
avatar = PyAvataaar()
  
# rendering the avatar in png format
avatar.render_png_file("AVATAR_1.png")