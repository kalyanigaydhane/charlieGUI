import os
from jira import JIRA

jira_url = os.environ['JIRA_URL']
jira_username = os.environ['JIRA_USERNAME']
jira_api_token = os.environ['JIRA_API_TOKEN']

jira = JIRA(jira_url, basic_auth=(jira_username, jira_api_token))

def list_jira_issues():
    jql_query = f'assignee = currentUser() AND (status = "In Progress" OR status = "Open") ORDER BY status DESC'
    assigned_issues = jira.search_issues(jql_query)
    return [{'id': issue.key, 'description': issue.fields.description, 'name': issue.fields.summary, 'status': issue.fields.status.name} for issue in assigned_issues]

def get_jira_issue(issue_id):
    issue = jira.issue(issue_id)
    return { 'name': issue.fields.summary, 'description': issue.fields.description, 'id': issue.key, 'status': issue.fields.status.name  }

def create_jira_issue():
    issue_dict = {
    'project': {'key': 'MAT'},
    'summary': 'creating ticket from Charlie',
    'description': 'Detailed ticket description.',
    'issuetype': {'name': 'Story'},
    }
    issue = jira.create_issue(fields=issue_dict)
    return { 'name': issue.fields.summary, 'description': issue.fields.description, 'id': issue.key, 'status': issue.fields.status.name  }