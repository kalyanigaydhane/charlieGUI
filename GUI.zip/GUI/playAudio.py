from playsound import playsound
import os

def play(audio_file):
    audio_file = os.path.dirname(__file__) + "\\audio\girlAudio\olivia\\" + audio_file
    playsound(audio_file)
