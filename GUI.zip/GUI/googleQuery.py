from googlesearch import search
from vmAssistant import *
from listen import *
from bs4 import BeautifulSoup

def say(string):
    print(string)
    speak(string)

# Make Google Query
def google_query(query):
    link = []
    for j in search(query, tld="us", num=10, stop=10, pause=2):
        link.append(j)
    print("Here is what I found for you:" + link)
    speak("Here is what I found for you")
    return link