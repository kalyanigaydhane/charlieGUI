# import required module
import os
from playsound import playsound

# for playing note.wav file
audio = "oliviaIntro.wav"
audio_file1 = os.path.dirname(__file__) + "\presetAudioResponses\girlAudio\olivia\\" + audio
audio_file2 = os.path.dirname(__file__) + "\presetAudioResponses\girlAudio\olivia\oliviaAfternoonGreet.wav"
audio_file3 = os.path.dirname(__file__) + "\presetAudioResponses\girlAudio\olivia\oliviaHowCanIHelp.wav"

playsound(audio_file1)
playsound(audio_file2)
playsound(audio_file3)

print('playing sound using  playsound')