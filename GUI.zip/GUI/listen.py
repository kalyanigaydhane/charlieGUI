import datetime
import os
import tkinter
import speech_recognition as sr
from vmAssistant import speak
import jira_issues
from playAudio import play
import datetime                    #To get the date and time
from tkinter import *              #For the graphics
from playsound import playsound    #To playsound
import keyboard                    #To get keyboard
from tkinter.ttk import *
  
# name_file = open("Assistant_name", "r")
# name_assistant = name_file.read()
name_assistant = "Charlie"

def get_salutation_appropriate_for_time_of_day():
    current_time = datetime.datetime.now()
    if current_time.hour < 12:
        return "oliviaFirstIntroAM.wav"
    elif current_time.hour < 17:
        return "oliviaFirstIntroNoon.wav"
    else:
        return "oliviaFirstIntroPM.wav"
    
def say(string):
    print(f"Charlie: {string}")
    speak(string)

last_status = None
def say_issue(issue):
    global last_status
    if issue['status'] != last_status:
        say('The following issues are ' + issue['status'])
        last_status = issue['status']
    say(f"Issue {issue['id']} is {issue['name']}")

def wait_for_converstation_to_start(recognizer):
    with sr.Microphone() as source:
        recognizer.pause_threshold = 0.5
        recognizer.adjust_for_ambient_noise(source, duration=2)
        audio=recognizer.listen(source,phrase_time_limit=2)
        try:
            query = recognizer.recognize_google(audio)
            print('You:', query)
        except (sr.UnknownValueError, sr.RequestError):
            wait_for_converstation_to_start(recognizer)

def have_conversation(recognizer, is_first_conversation=False):
    audio = None

    with sr.Microphone() as source:
        recognizer.pause_threshold = 1
        recognizer.adjust_for_ambient_noise(source, duration=3)
        salutation = get_salutation_appropriate_for_time_of_day()
        if is_first_conversation:
            play(salutation)
        # else:
            # say("Hi, how can I help you?")
            # play("oliviaHowCanIHelp.wav")

        try:
            audio=recognizer.listen(source,phrase_time_limit=5)
        except sr.WaitTimeoutError:
            # say("Can you please say that again?")
            play('oliviaRepeat.wav')

            return have_conversation(recognizer)

    if audio:
        try:
            query = recognizer.recognize_google(audio, language='en-US')
            print('You:', query)
            # say("OK, no problem, I'll work on that for you!")
            # play('oliviaNoProblem.wav')
            if ("list" in query or "show" in query) and "issues" in query:
                # say("Here are the issues I found for you")
                play('oliviaJiraSearchResults.wav')
                for issue in jira_issues.list_jira_issues():
                    say_issue(issue)
            elif ("show" in query or "tell" in query) and "issue " in query:
                # say("I found your issue, here's some info about it")
                play('oliviaJiraTicketDetail.wav')
                issue_id = jira_issues.get_jira_issue(f"ax-{query.split(' ')[-1]}")
                say_issue(issue_id)
            elif ("create" in query) and ("issue" in query or "shoe" in query):
                # say("ok i am creating issue")
                play("oliviaCreatingIssueNow.wav")
                issue_id = jira_issues.create_jira_issue()
                # print(issue_id)
                say_issue(issue_id)
            elif "exit" in query or "thank you" in query or "bye" in query or "ok" in query:
                play("oliviaQuestionExit.wav")  
            elif "yes" in query:    
                exit()  
            else:
                play("oliviaRepeat.wav")

        except sr.UnknownValueError:
            # say("I'm sorry, I can't hear you")
            play('oliviaCantHearYou.wav')
            return have_conversation(recognizer)
        except sr.RequestError:
            # say("Can you please say that again?")
            play('oliviaRepeat.wav')
            return have_conversation(recognizer)

#Listen to user input
def listen():
    recognizer = sr.Recognizer()
    say("Listening")    
    is_first_conversation = True
    while True:
        wait_for_converstation_to_start(recognizer)
        have_conversation(recognizer, is_first_conversation)
        is_first_conversation = False


#GUI code is here for now
def Process_audio():
    if __name__ == "__main__":
        listen()

def info():

  info_screen = Toplevel(screen)
  info_screen.title("Info")
  info_screen.iconbitmap(os.path.dirname(__file__) + '\\app_icon.ico')

  creator_label = Label(info_screen,text = "Hello Team Innovation, I am Charlie")
  creator_label.pack()

  Age_label = Label(info_screen, text= "virtual voice assistant")
  Age_label.pack()

  for_label = Label(info_screen, text = "For vermont mutual")
  for_label.pack()

keyboard.add_hotkey("F4", Process_audio)

def main_screen():

      global screen
      screen = Tk()
      screen.title(name_assistant)
      screen.geometry("100x250")
      screen.iconbitmap(os.path.dirname(__file__) + '\\app_icon.ico')


    #   name_label = Label(text = name_assistant,width = 300, bg = "black", fg="white", font = ("Calibri", 13))
    #   name_label.pack()

      l1 = tkinter.Label(text = name_assistant,width = 300, bg = "black", fg="white", font = ("Calibri", 13))


      microphone_photo = PhotoImage(file = os.path.dirname(__file__) + "\\dearCharlie_2_100x100.png")
      microphone_button = Button(image=microphone_photo, command = Process_audio)
      microphone_button.pack(pady=10)

    #   settings_photo = PhotoImage(file = os.path.dirname(__file__) + "\\settings.png")
    #   settings_button = Button(image=settings_photo, command = change_name_window)
    #   settings_button.pack(pady=10)
       
      info_button = Button(text ="Info", command = info)
      info_button.pack(pady=10)

      screen.mainloop()


main_screen()
